﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemSpawnPoint : MonoBehaviour
{
    [Header("Spawn Settings")]
    public int maxItems = 5; // Giới hạn số lượng vật phẩm có thể tồn tại trong scene
    private int currentItemCount = 0; // Số lượng vật phẩm hiện có trong scene
    public float timeSpawn = 10f; // Thời gian xuất hiện giữa các vật phẩm
    public float minX, maxX; // Tọa độ X cho vùng spawn
    public float minY, maxY; // Tọa độ Y cho vùng spawn (nếu cần)

    [Header("Item Prefabs")]
    public List<GameObject> itemPrefabs; // Danh sách prefab của 3 item (ItemBomb, ItemSpikeBomb, ItemStickyBomb)

    [Header("Gravity Settings")]
    public float initialGravityScale = 0.5f; // Gravity Scale ban đầu
    public float normalGravityScale = 1f; // Gravity Scale sau khi chạm đất

    [Header("Existence Range")]
    public float minExistX; // Tọa độ X cho phạm vi tồn tại của vật phẩm
    public float maxExistX; // Tọa độ X cho phạm vi tồn tại của vật phẩm
    public float minExistY; // Tọa độ Y cho phạm vi tồn tại của vật phẩm
    public float maxExistY; // Tọa độ Y cho phạm vi tồn tại của vật phẩm

    private void Start()
    {
        // Bắt đầu Coroutine để spawn vật phẩm mỗi timeSpawn giây
        StartCoroutine(SpawnItemRoutine());
    }

    private IEnumerator SpawnItemRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(timeSpawn);

            // Kiểm tra số lượng vật phẩm trong scene, nếu đã đạt maxItems thì không spawn thêm
            if (currentItemCount < maxItems)
            {
                SpawnRandomItem();
            }
        }
    }

    private void SpawnRandomItem()
    {
        // Random vị trí spawn trong khoảng minX - maxX và minY - maxY
        float randomX = Random.Range(minX, maxX);
        float randomY = Random.Range(minY, maxY);
        Vector2 spawnPosition = new Vector2(randomX, randomY);

        // Chọn ngẫu nhiên một prefab trong danh sách itemPrefabs
        int randomIndex = Random.Range(0, itemPrefabs.Count);
        GameObject selectedItem = itemPrefabs[randomIndex];

        // Tạo vật phẩm tại vị trí spawn
        GameObject spawnedItem = Instantiate(selectedItem, spawnPosition, Quaternion.identity);
        currentItemCount++;  // Tăng số lượng vật phẩm hiện có

        // Thiết lập Gravity Scale ban đầu cho vật phẩm
        Rigidbody2D rb = spawnedItem.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.gravityScale = initialGravityScale;

            // Gán script xử lý va chạm để chuyển Gravity Scale về bình thường
            FallingItem fallingItem = spawnedItem.AddComponent<FallingItem>();
            fallingItem.Setup(normalGravityScale, minExistX, maxExistX, minExistY, maxExistY, this);

            // Bỏ qua va chạm với collider của Player
            //Collider2D playerCollider = GameObject.FindGameObjectWithTag("Player").GetComponent<Collider2D>();
            //if (playerCollider != null)
            //{
            //    Physics2D.IgnoreCollision(rb.GetComponent<Collider2D>(), playerCollider);
            //}
        }

        // Kiểm tra và xóa vật phẩm cũ nếu quá số lượng tối đa
        if (currentItemCount > maxItems)
        {
            RemoveOldestItem();
        }
    }

    // Hàm để xóa vật phẩm cũ khi vượt quá maxItems
    private void RemoveOldestItem()
    {
        // Tìm tất cả các vật phẩm trong scene (tạo một danh sách các vật phẩm)
        GameObject[] allItems = GameObject.FindGameObjectsWithTag("Item");

        if (allItems.Length > 0)
        {
            // Xóa vật phẩm đầu tiên trong danh sách (hoặc có thể xóa vật phẩm ngẫu nhiên nếu muốn)
            Destroy(allItems[0]);
            currentItemCount--;  // Giảm số lượng vật phẩm hiện có
        }
    }

    // Phương thức giảm số lượng item khi một item biến mất
    public void DecreaseItemCount()
    {
        currentItemCount--;

        // Nếu số lượng vật phẩm dưới maxItems, spawn tiếp
        if (currentItemCount < maxItems)
        {
            SpawnRandomItem();
        }
    }

    // FallingItem được kết hợp vào bên trong ItemSpawnPoint
    public class FallingItem : MonoBehaviour
    {
        private Rigidbody2D rb;
        private float normalGravityScale;
        private float minExistX, maxExistX, minExistY, maxExistY;
        private ItemSpawnPoint spawnPoint; // Reference đến ItemSpawnPoint để gọi DecreaseItemCount

        // Thiết lập Gravity Scale khi chạm đất và phạm vi tồn tại của vật phẩm
        public void Setup(float normalGravity, float minX, float maxX, float minY, float maxY, ItemSpawnPoint itemSpawnPoint)
        {
            rb = GetComponent<Rigidbody2D>();
            normalGravityScale = normalGravity;
            minExistX = minX;
            maxExistX = maxX;
            minExistY = minY;
            maxExistY = maxY;
            spawnPoint = itemSpawnPoint;
        }

        private void Update()
        {
            // Kiểm tra nếu vật phẩm ra ngoài phạm vi xác định
            if (transform.position.x < minExistX || transform.position.x > maxExistX ||
                transform.position.y < minExistY || transform.position.y > maxExistY)
            {
                // Gọi phương thức DecreaseItemCount để giảm số lượng vật phẩm
                spawnPoint.DecreaseItemCount();

                Destroy(gameObject);  // Xóa vật phẩm nếu nó ra ngoài phạm vi
            }
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            // Khi vật phẩm chạm đất, khôi phục Gravity Scale về bình thường
            if (collision.gameObject.CompareTag("Ground")) // Đảm bảo mặt đất có tag là "Ground"
            {
                rb.gravityScale = normalGravityScale;
            }
        }
    }
}
